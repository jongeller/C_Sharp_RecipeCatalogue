﻿using System;
using Cookbook;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;

namespace CookbookTests
{
    [TestFixture]
    public class RecipeTests
    {
        //[Test]
        //public void CreateIngredient()
        //{
        //    Ingredient TestIngredient = new Ingredient("Something",2,"Qty");

        //    Assert.AreEqual(2,TestIngredient.Amount);
        //    Assert.AreEqual("Something", TestIngredient.Name);
        //    Assert.AreEqual("Qty",TestIngredient.UnitOfMeasure);
        //}

        //[Test]
        //public void DummyDataPopulationSuccessful()
        //{
        //    List<Recipe> TestRecipies = new List<Recipe>();
        //    DummyData.Load(ref TestRecipies);

        //    Assert.AreEqual("Chicken Parmesan", TestRecipies[0].Title);
        //}
    }
}
